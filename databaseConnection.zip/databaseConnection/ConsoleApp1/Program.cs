﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                System.Data.SqlClient.SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
                builder.DataSource = "ceb03.database.windows.net";
                builder.UserID = "dhanushka";
                builder.Password = "Sandu@2019";
                builder.InitialCatalog = "CEB";

                using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
                {
                    Console.WriteLine("\nQuery data from Cloud database for Testing:");
                    Console.WriteLine("=========================================\n");

                    connection.Open();
                    StringBuilder sb = new StringBuilder();
                    sb.Append("SELECT * FROM Users ");//get user table data
                   // sb.Append("FROM [SalesLT].[ProductCategory] pc ");
                  //  sb.Append("JOIN [SalesLT].[Product] p ");
                  //  sb.Append("ON pc.productcategoryid = p.productcategoryid;");
                    String sql = sb.ToString();

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Console.WriteLine("{0} {1} {2} {3} {4}", reader.GetValue(0),reader.GetValue(1), reader.GetValue(2),reader.GetValue(3), reader.GetValue(4));
                            }
                        }
                    }
                }
            }
            catch (SqlException e)
            {
                Console.WriteLine(e.ToString());
            }
            Console.ReadLine();
        }

    }
}

